#include <cuda/std/cstdint>
#include <cub/block/block_load.cuh>
#include <cub/block/block_store.cuh>

using algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load = cub::BlockLoad<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_LOAD_TRANSPOSE, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load = typename algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load = alignof(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load);
extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_alloc(::cuda::std::int32_t* src, ::cuda::std::int32_t *dst) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load(temp_storage).Load(src, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_alloc__abi(void *__ret, void *src, void *dst) {
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_alloc(cast_src, cast_dst);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load *temp_storage, ::cuda::std::int32_t* src, ::cuda::std::int32_t *dst) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load(*temp_storage).Load(src, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32__abi(void *__ret, void *temp_storage, void *src, void *dst) {
    temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load *cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load *>(temp_storage);
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32(cast_temp_storage, cast_src, cast_dst);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(::cuda::std::int32_t* src, ::cuda::std::int32_t *dst, ::cuda::std::int64_t offset) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load(temp_storage).Load((src + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc__abi(void *__ret, void *src, void *dst, ::cuda::std::int64_t offset) {
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(cast_src, cast_dst, offset);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load *temp_storage, ::cuda::std::int32_t* src, ::cuda::std::int32_t *dst, ::cuda::std::int64_t offset) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load(*temp_storage).Load((src + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *temp_storage, void *src, void *dst, ::cuda::std::int64_t offset) {
    temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load *cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load *>(temp_storage);
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_S3fe94d67e54de261d2e5_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime(cast_temp_storage, cast_src, cast_dst, offset);
    return 0;
}

using algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store = cub::BlockStore<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_STORE_TRANSPOSE, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store = typename algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store = alignof(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store);
extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_alloc(::cuda::std::int32_t* dst, ::cuda::std::int32_t *src) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store(temp_storage).Store(dst, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_alloc__abi(void *__ret, void *dst, void *src) {
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_alloc(cast_dst, cast_src);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store *temp_storage, ::cuda::std::int32_t* dst, ::cuda::std::int32_t *src) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store(*temp_storage).Store(dst, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32__abi(void *__ret, void *temp_storage, void *dst, void *src) {
    temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store *cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store *>(temp_storage);
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32(cast_temp_storage, cast_dst, cast_src);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(::cuda::std::int32_t* dst, ::cuda::std::int32_t *src, ::cuda::std::int64_t offset) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store(temp_storage).Store((dst + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc__abi(void *__ret, void *dst, void *src, ::cuda::std::int64_t offset) {
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(cast_dst, cast_src, offset);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store *temp_storage, ::cuda::std::int32_t* dst, ::cuda::std::int32_t *src, ::cuda::std::int64_t offset) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store(*temp_storage).Store((dst + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *temp_storage, void *dst, void *src, ::cuda::std::int64_t offset) {
    temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store *cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store *>(temp_storage);
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S0fe22d9efc01e711ea3b_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime(cast_temp_storage, cast_dst, cast_src, offset);
    return 0;
}
