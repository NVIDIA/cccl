#include <cuda/std/cstdint>
#include <cub/block/block_load.cuh>
#include <cub/block/block_store.cuh>

using algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load = cub::BlockLoad<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_LOAD_TRANSPOSE, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load = typename algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load = alignof(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load);
extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_alloc(::cuda::std::int32_t* src, ::cuda::std::int32_t *dst) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load(temp_storage).Load(src, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_alloc__abi(void *__ret, void *abi_src, void *abi_dst) {
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_alloc(abi_cast_src, abi_cast_dst);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load *temp_storage, ::cuda::std::int32_t* src, ::cuda::std::int32_t *dst) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load(*temp_storage).Load(src, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32__abi(void *__ret, void *abi_temp_storage, void *abi_src, void *abi_dst) {
    temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load *abi_cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load *>(abi_temp_storage);
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32(abi_cast_temp_storage, abi_cast_src, abi_cast_dst);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(::cuda::std::int32_t* src, ::cuda::std::int32_t *dst, ::cuda::std::int64_t offset) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load(temp_storage).Load((src + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc__abi(void *__ret, void *abi_src, void *abi_dst, ::cuda::std::int64_t abi_offset) {
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(abi_cast_src, abi_cast_dst, abi_offset);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load *temp_storage, ::cuda::std::int32_t* src, ::cuda::std::int32_t *dst, ::cuda::std::int64_t offset) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load(*temp_storage).Load((src + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *abi_temp_storage, void *abi_src, void *abi_dst, ::cuda::std::int64_t abi_offset) {
    temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load *abi_cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load *>(abi_temp_storage);
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sa3d1cd57c4972911c74b_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime(abi_cast_temp_storage, abi_cast_src, abi_cast_dst, abi_offset);
    return 0;
}

using algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store = cub::BlockStore<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_STORE_TRANSPOSE, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store = typename algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store = alignof(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store);
extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_alloc(::cuda::std::int32_t* dst, ::cuda::std::int32_t *src) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store(temp_storage).Store(dst, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_alloc__abi(void *__ret, void *abi_dst, void *abi_src) {
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_alloc(abi_cast_dst, abi_cast_src);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store *temp_storage, ::cuda::std::int32_t* dst, ::cuda::std::int32_t *src) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store(*temp_storage).Store(dst, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32__abi(void *__ret, void *abi_temp_storage, void *abi_dst, void *abi_src) {
    temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store *abi_cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store *>(abi_temp_storage);
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32(abi_cast_temp_storage, abi_cast_dst, abi_cast_src);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(::cuda::std::int32_t* dst, ::cuda::std::int32_t *src, ::cuda::std::int64_t offset) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store(temp_storage).Store((dst + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc__abi(void *__ret, void *abi_dst, void *abi_src, ::cuda::std::int64_t abi_offset) {
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(abi_cast_dst, abi_cast_src, abi_offset);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store *temp_storage, ::cuda::std::int32_t* dst, ::cuda::std::int32_t *src, ::cuda::std::int64_t offset) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store(*temp_storage).Store((dst + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *abi_temp_storage, void *abi_dst, void *abi_src, ::cuda::std::int64_t abi_offset) {
    temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store *abi_cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store *>(abi_temp_storage);
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_S3b9cd08ed25824e56587_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime(abi_cast_temp_storage, abi_cast_dst, abi_cast_src, abi_offset);
    return 0;
}
