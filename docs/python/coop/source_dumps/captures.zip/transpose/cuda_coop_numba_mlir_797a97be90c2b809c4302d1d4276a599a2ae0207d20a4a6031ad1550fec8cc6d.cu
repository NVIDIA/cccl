#include <cuda/std/cstdint>
#include <cub/block/block_load.cuh>
#include <cub/block/block_store.cuh>

using algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load = cub::BlockLoad<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_LOAD_TRANSPOSE, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load = typename algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load = alignof(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load);
extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_alloc(::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load(temp_storage).Load(param_0, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_alloc__abi(void *__ret, void *abi_param_0, void *abi_param_1) {
    ::cuda::std::int32_t *abi_cast_0 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_alloc(abi_cast_0, abi_cast_1);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load *temp_storage, ::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load(*temp_storage).Load(param_0, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32__abi(void *__ret, void *abi_param_0, void *abi_param_1, void *abi_param_2) {
    temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load *abi_cast_0 = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    ::cuda::std::int32_t *abi_cast_2 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_2);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32(abi_cast_0, abi_cast_1, abi_cast_2);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1, ::cuda::std::int64_t param_2) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load(temp_storage).Load((param_0 + param_2), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc__abi(void *__ret, void *abi_param_0, void *abi_param_1, ::cuda::std::int64_t abi_param_2) {
    ::cuda::std::int32_t *abi_cast_0 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(abi_cast_0, abi_cast_1, abi_param_2);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime(temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load *temp_storage, ::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1, ::cuda::std::int64_t param_2) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load(*temp_storage).Load((param_0 + param_2), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *abi_param_0, void *abi_param_1, void *abi_param_2, ::cuda::std::int64_t abi_param_3) {
    temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load *abi_cast_0 = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    ::cuda::std::int32_t *abi_cast_2 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_2);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_TRANSPOSE__1__1_Sbc234bd4fbe09333e713_Load_Puint8_Pint32_A2_int32_Offsetint64Runtime(abi_cast_0, abi_cast_1, abi_cast_2, abi_param_3);
    return 0;
}

using algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store = cub::BlockStore<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_STORE_TRANSPOSE, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store = typename algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store = alignof(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store);
extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_alloc(::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store(temp_storage).Store(param_0, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_alloc__abi(void *__ret, void *abi_param_0, void *abi_param_1) {
    ::cuda::std::int32_t *abi_cast_0 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_alloc(abi_cast_0, abi_cast_1);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store *temp_storage, ::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store(*temp_storage).Store(param_0, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32__abi(void *__ret, void *abi_param_0, void *abi_param_1, void *abi_param_2) {
    temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store *abi_cast_0 = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    ::cuda::std::int32_t *abi_cast_2 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_2);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32(abi_cast_0, abi_cast_1, abi_cast_2);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1, ::cuda::std::int64_t param_2) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store temp_storage;
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store(temp_storage).Store((param_0 + param_2), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc__abi(void *__ret, void *abi_param_0, void *abi_param_1, ::cuda::std::int64_t abi_param_2) {
    ::cuda::std::int32_t *abi_cast_0 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime_alloc(abi_cast_0, abi_cast_1, abi_param_2);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime(temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store *temp_storage, ::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1, ::cuda::std::int64_t param_2) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store(*temp_storage).Store((param_0 + param_2), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *abi_param_0, void *abi_param_1, void *abi_param_2, ::cuda::std::int64_t abi_param_3) {
    temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store *abi_cast_0 = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    ::cuda::std::int32_t *abi_cast_2 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_2);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_TRANSPOSE__1__1_Sbb6fd6701ab895eca426_Store_Puint8_Pint32_A2_int32_Offsetint64Runtime(abi_cast_0, abi_cast_1, abi_cast_2, abi_param_3);
    return 0;
}
