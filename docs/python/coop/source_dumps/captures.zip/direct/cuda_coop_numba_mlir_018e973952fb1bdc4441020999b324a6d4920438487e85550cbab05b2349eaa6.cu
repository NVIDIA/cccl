#include <cuda/std/cstdint>
#include <cub/block/block_load.cuh>
#include <cub/block/block_store.cuh>

using algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load = cub::BlockLoad<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_LOAD_DIRECT, 1, 1>;
extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load_Pint32_A2_int32(::cuda::std::int32_t* src, ::cuda::std::int32_t *dst) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load().Load(src, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load_Pint32_A2_int32__abi(void *__ret, void *abi_src, void *abi_dst) {
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load_Pint32_A2_int32(abi_cast_src, abi_cast_dst);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load_Pint32_A2_int32_Offsetint64Runtime(::cuda::std::int32_t* src, ::cuda::std::int32_t *dst, ::cuda::std::int64_t offset) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load().Load((src + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *abi_src, void *abi_dst, ::cuda::std::int64_t abi_offset) {
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sce140d1f74392983737d_Load_Pint32_A2_int32_Offsetint64Runtime(abi_cast_src, abi_cast_dst, abi_offset);
    return 0;
}

using algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store = cub::BlockStore<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_STORE_DIRECT, 1, 1>;
extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store_Pint32_A2_int32(::cuda::std::int32_t* dst, ::cuda::std::int32_t *src) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store().Store(dst, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store_Pint32_A2_int32__abi(void *__ret, void *abi_dst, void *abi_src) {
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store_Pint32_A2_int32(abi_cast_dst, abi_cast_src);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store_Pint32_A2_int32_Offsetint64Runtime(::cuda::std::int32_t* dst, ::cuda::std::int32_t *src, ::cuda::std::int64_t offset) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store().Store((dst + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *abi_dst, void *abi_src, ::cuda::std::int64_t abi_offset) {
    ::cuda::std::int32_t *abi_cast_dst = reinterpret_cast<::cuda::std::int32_t *>(abi_dst);
    ::cuda::std::int32_t *abi_cast_src = reinterpret_cast<::cuda::std::int32_t *>(abi_src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sc0a4c6d6fae19d034737_Store_Pint32_A2_int32_Offsetint64Runtime(abi_cast_dst, abi_cast_src, abi_offset);
    return 0;
}
