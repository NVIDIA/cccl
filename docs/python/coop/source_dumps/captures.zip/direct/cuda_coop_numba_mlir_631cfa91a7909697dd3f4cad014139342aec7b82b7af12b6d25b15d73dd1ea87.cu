#include <cuda/std/cstdint>
#include <cub/block/block_load.cuh>
#include <cub/block/block_store.cuh>

using algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load = cub::BlockLoad<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_LOAD_DIRECT, 1, 1>;
extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load_Pint32_A2_int32(::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load().Load(param_0, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load_Pint32_A2_int32__abi(void *__ret, void *abi_param_0, void *abi_param_1) {
    ::cuda::std::int32_t *abi_cast_0 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load_Pint32_A2_int32(abi_cast_0, abi_cast_1);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load_Pint32_A2_int32_Offsetint64Runtime(::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1, ::cuda::std::int64_t param_2) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load().Load((param_0 + param_2), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *abi_param_0, void *abi_param_1, ::cuda::std::int64_t abi_param_2) {
    ::cuda::std::int32_t *abi_cast_0 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_S752890a5ba7735444b91_Load_Pint32_A2_int32_Offsetint64Runtime(abi_cast_0, abi_cast_1, abi_param_2);
    return 0;
}

using algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store = cub::BlockStore<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_STORE_DIRECT, 1, 1>;
extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store_Pint32_A2_int32(::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store().Store(param_0, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store_Pint32_A2_int32__abi(void *__ret, void *abi_param_0, void *abi_param_1) {
    ::cuda::std::int32_t *abi_cast_0 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store_Pint32_A2_int32(abi_cast_0, abi_cast_1);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store_Pint32_A2_int32_Offsetint64Runtime(::cuda::std::int32_t* param_0, ::cuda::std::int32_t *param_1, ::cuda::std::int64_t param_2) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store().Store((param_0 + param_2), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(param_1));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *abi_param_0, void *abi_param_1, ::cuda::std::int64_t abi_param_2) {
    ::cuda::std::int32_t *abi_cast_0 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_0);
    ::cuda::std::int32_t *abi_cast_1 = reinterpret_cast<::cuda::std::int32_t *>(abi_param_1);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_Sb73a625bd9e1bdb4d87b_Store_Pint32_A2_int32_Offsetint64Runtime(abi_cast_0, abi_cast_1, abi_param_2);
    return 0;
}
