#include <cuda/std/cstdint>
#include <cub/block/block_load.cuh>
#include <cub/block/block_store.cuh>

using algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load = cub::BlockLoad<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_LOAD_DIRECT, 1, 1>;
extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load_Pint32_A2_int32(::cuda::std::int32_t* src, ::cuda::std::int32_t *dst) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load().Load(src, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load_Pint32_A2_int32__abi(void *__ret, void *src, void *dst) {
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load_Pint32_A2_int32(cast_src, cast_dst);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load_Pint32_A2_int32_Offsetint64Runtime(::cuda::std::int32_t* src, ::cuda::std::int32_t *dst, ::cuda::std::int64_t offset) {
    algorithm_t_cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load().Load((src + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(dst));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *src, void *dst, ::cuda::std::int64_t offset) {
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    cuda_coop_numba_mlir_block_load__cuda__std__int32_t__128__2____cub__BLOCK_LOAD_DIRECT__1__1_Sfd7c40984782d1ef6724_Load_Pint32_A2_int32_Offsetint64Runtime(cast_src, cast_dst, offset);
    return 0;
}

using algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store = cub::BlockStore<::cuda::std::int32_t, 128, 2, ::cub::BLOCK_STORE_DIRECT, 1, 1>;
extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store_Pint32_A2_int32(::cuda::std::int32_t* dst, ::cuda::std::int32_t *src) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store().Store(dst, *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store_Pint32_A2_int32__abi(void *__ret, void *dst, void *src) {
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store_Pint32_A2_int32(cast_dst, cast_src);
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store_Pint32_A2_int32_Offsetint64Runtime(::cuda::std::int32_t* dst, ::cuda::std::int32_t *src, ::cuda::std::int64_t offset) {
    algorithm_t_cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store().Store((dst + offset), *reinterpret_cast<::cuda::std::int32_t (*)[2]>(src));
}

extern "C" __device__ int cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store_Pint32_A2_int32_Offsetint64Runtime__abi(void *__ret, void *dst, void *src, ::cuda::std::int64_t offset) {
    ::cuda::std::int32_t *cast_dst = reinterpret_cast<::cuda::std::int32_t *>(dst);
    ::cuda::std::int32_t *cast_src = reinterpret_cast<::cuda::std::int32_t *>(src);
    cuda_coop_numba_mlir_block_store__cuda__std__int32_t__128__2____cub__BLOCK_STORE_DIRECT__1__1_S7d3fe7154206ca4f225d_Store_Pint32_A2_int32_Offsetint64Runtime(cast_dst, cast_src, offset);
    return 0;
}
