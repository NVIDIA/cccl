#include <cuda/std/cstdint>
#include <cub/block/block_scan.cuh>


extern "C" __device__ ::cuda::std::int32_t cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(::cuda::std::int32_t, ::cuda::std::int32_t);

using algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan = cub::BlockScan<::cuda::std::int32_t, 128, ::cub::BLOCK_SCAN_RAKING, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan = typename algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan = alignof(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan);
extern "C" __device__ void cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc(::cuda::std::int32_t& input, ::cuda::std::int32_t& output) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan temp_storage;
    auto scan_op = [](const ::cuda::std::int32_t& wp_0, const ::cuda::std::int32_t& wp_1) {
        return cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(wp_0, wp_1);
    };
    algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan(temp_storage).InclusiveScan(input, output, scan_op);
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc__abi(void *__ret, ::cuda::std::int32_t abi_input) {
    ::cuda::std::int32_t abi_ref_input = abi_input;
    ::cuda::std::int32_t abi_out;
    cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc(abi_ref_input, abi_out);
    *reinterpret_cast<::cuda::std::int32_t *>(__ret) = abi_out;
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan *temp_storage, ::cuda::std::int32_t& input, ::cuda::std::int32_t& output) {
    auto scan_op = [](const ::cuda::std::int32_t& wp_0, const ::cuda::std::int32_t& wp_1) {
        return cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(wp_0, wp_1);
    };
    algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan(*temp_storage).InclusiveScan(input, output, scan_op);
}

extern "C" __device__ int cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32__abi(void *__ret, void *abi_temp_storage, ::cuda::std::int32_t abi_input) {
    temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan *abi_cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan *>(abi_temp_storage);
    ::cuda::std::int32_t abi_ref_input = abi_input;
    ::cuda::std::int32_t abi_out;
    cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sb28422764b8b888b7fea_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(abi_cast_temp_storage, abi_ref_input, abi_out);
    *reinterpret_cast<::cuda::std::int32_t *>(__ret) = abi_out;
    return 0;
}

