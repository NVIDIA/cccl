#include <cuda/std/cstdint>
#include <cub/block/block_scan.cuh>


extern "C" __device__ ::cuda::std::int32_t cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(::cuda::std::int32_t, ::cuda::std::int32_t);

using algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan = cub::BlockScan<::cuda::std::int32_t, 128, ::cub::BLOCK_SCAN_RAKING, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan = typename algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan = alignof(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan);
extern "C" __device__ void cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc(::cuda::std::int32_t& input, ::cuda::std::int32_t& output) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan temp_storage;
    auto scan_op = [](const ::cuda::std::int32_t& wp_0, const ::cuda::std::int32_t& wp_1) {
        return cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(wp_0, wp_1);
    };
    algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan(temp_storage).InclusiveScan(input, output, scan_op);
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc__abi(void *__ret, ::cuda::std::int32_t input) {
    ::cuda::std::int32_t ref_input = input;
    ::cuda::std::int32_t out;
    cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc(ref_input, out);
    *reinterpret_cast<::cuda::std::int32_t *>(__ret) = out;
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan *temp_storage, ::cuda::std::int32_t& input, ::cuda::std::int32_t& output) {
    auto scan_op = [](const ::cuda::std::int32_t& wp_0, const ::cuda::std::int32_t& wp_1) {
        return cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(wp_0, wp_1);
    };
    algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan(*temp_storage).InclusiveScan(input, output, scan_op);
}

extern "C" __device__ int cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32__abi(void *__ret, void *temp_storage, ::cuda::std::int32_t input) {
    temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan *cast_temp_storage = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan *>(temp_storage);
    ::cuda::std::int32_t ref_input = input;
    ::cuda::std::int32_t out;
    cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sc04693bd5da8e8d2f9ca_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(cast_temp_storage, ref_input, out);
    *reinterpret_cast<::cuda::std::int32_t *>(__ret) = out;
    return 0;
}

