#include <cuda/std/cstdint>
#include <cub/block/block_scan.cuh>


extern "C" __device__ ::cuda::std::int32_t cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(::cuda::std::int32_t, ::cuda::std::int32_t);

using algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan = cub::BlockScan<::cuda::std::int32_t, 128, ::cub::BLOCK_SCAN_RAKING, 1, 1>;
using temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan = typename algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan::TempStorage;
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_bytes_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan = sizeof(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan);
__device__ constexpr unsigned cuda_coop_numba_mlir_temp_storage_alignment_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan = alignof(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan);
extern "C" __device__ void cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc(::cuda::std::int32_t& param_0, ::cuda::std::int32_t& param_1) {
    __shared__ temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan temp_storage;
    auto param_2 = [](const ::cuda::std::int32_t& wp_0, const ::cuda::std::int32_t& wp_1) {
        return cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(wp_0, wp_1);
    };
    algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan(temp_storage).InclusiveScan(param_0, param_1, param_2);
    __syncthreads();
}
extern "C" __device__ int cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc__abi(void *__ret, ::cuda::std::int32_t abi_param_0) {
    ::cuda::std::int32_t abi_ref_0 = abi_param_0;
    ::cuda::std::int32_t abi_out;
    cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32_alloc(abi_ref_0, abi_out);
    *reinterpret_cast<::cuda::std::int32_t *>(__ret) = abi_out;
    return 0;
}

extern "C" __device__ void cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan *temp_storage, ::cuda::std::int32_t& param_0, ::cuda::std::int32_t& param_1) {
    auto param_2 = [](const ::cuda::std::int32_t& wp_0, const ::cuda::std::int32_t& wp_1) {
        return cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(wp_0, wp_1);
    };
    algorithm_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan(*temp_storage).InclusiveScan(param_0, param_1, param_2);
}

extern "C" __device__ int cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32__abi(void *__ret, void *abi_param_0, ::cuda::std::int32_t abi_param_1) {
    temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan *abi_cast_0 = reinterpret_cast<temp_storage_t_cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan *>(abi_param_0);
    ::cuda::std::int32_t abi_ref_1 = abi_param_1;
    ::cuda::std::int32_t abi_out;
    cuda_coop_numba_mlir_block_scan__cuda__std__int32_t__128____cub__BLOCK_SCAN_RAKING__1__1_Sdca246addb2989ff1e88_InclusiveScan_Puint8_Rint32_Rint32_cuda_coop_numba_mlir_Fmain___maximum_e873567dc882d50f9e6f_int32__int32_int32(abi_cast_0, abi_ref_1, abi_out);
    *reinterpret_cast<::cuda::std::int32_t *>(__ret) = abi_out;
    return 0;
}

